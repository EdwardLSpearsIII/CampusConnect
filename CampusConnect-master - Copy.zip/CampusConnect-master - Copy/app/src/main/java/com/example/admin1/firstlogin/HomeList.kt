package com.example.admin1.firstlogin

data class HomeList(var name: String, var number: String, var email: String, var logo: Int)