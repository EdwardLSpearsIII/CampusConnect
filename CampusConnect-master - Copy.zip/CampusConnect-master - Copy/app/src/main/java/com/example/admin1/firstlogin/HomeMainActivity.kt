package com.example.admin1.firstlogin

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.ListView

class HomeMainActivity: AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_customer)

        var listView = findViewById<ListView>(R.id.llistView)
        var arrCompany: ArrayList<HomeList> = ArrayList()

        arrCompany.add(HomeList("Company 1", "1234567", "example@pvamu.edu", R.drawable.smiley))
        arrCompany.add(HomeList("Company 2", "7654321", "example2@pvamu.edu", R.drawable.redsmiley))
        arrCompany.add(HomeList("Company 3", "2468024", "exampl3@pvamu.edu", R.drawable.bluesmiley))

        listView.adapter = CustomAdapter(applicationContext, arrCompany)
    }
}